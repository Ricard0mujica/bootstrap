$( function () { //$(document).ready(function(){

	// Servicios
	$('#servicios-tab a').click( function () {
		$('#servicios-tab-responsive a').removeClass('active');
		$('#servicios-tab-responsive a[href="' + $(this).attr('href') + '"]').addClass('active');
	});
	$('#servicios-tab-responsive a').click( function () {
		$('#servicios-tab a').removeClass('active');
		$('#servicios-tab a[href="' + $(this).attr('href') + '"]').addClass('active');
	});
	
	// Proyectos
	var proyectos = $('.proyecto-lista');
	proyectos.isotope({
		// options
		itemSelector: '.proyecto-item',
		layoutMode: 'masonry'
	});
	
	setTimeout(function () {
		proyectos.isotope({ filter: '*' });
	}, 1000);
	
	$('.proyecto-filtro').click( function () {
		var filtro = $(this).data('filtro');
		proyectos.isotope({ filter: filtro });
		$('.proyecto-filtro').removeClass('active');
		var filtro = $(this).addClass('active');
		
	});
	
	$('button').click( function () {
		
		var active = $(this).addclass('active');
		
	});
	
	// Fetch all the forms we want to apply custom Bootstrap validation styles to
							var forms = document.getElementsByClassName('needs-validation');
							// Loop over them and prevent submission
							var validation = Array.prototype.filter.call(forms, function(form) {
								form.addEventListener('submit', function(event) {
									if (form.checkValidity() === false) {
									event.preventDefault();
									event.stopPropagation();
									}
									form.classList.add('was-validated');
									}, false);
									});
	
}); // cierre del $(document).ready( function () {})