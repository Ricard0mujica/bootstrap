<?php

$nombre = $_POST['campo_Nombre'];
$asunto = $_POST['campo_Asunto'];
$email = $_POST['campo_Email'];
$mensaje = $_POST['campo_Mensaje'];
$privacidad = $_POST['campo_Privacidad'];

$cuerpo = "<html><head></head><body><style>table {font-family:tahoma,sans-serif;} th {text-align:right;}</style>\n";
$cuerpo .= "<table>\n";
$cuerpo .= "<tr><th>Nombre: </th><td>".$nombre."</td></tr>\n";
$cuerpo .= "<tr><th>Asunto: </th><td>".$asunto."</td></tr>\n";
$cuerpo .= "<tr><th>Email: </th><td>".$email."</td></tr>\n";
$cuerpo .= "<tr><th>Mensaje: </th><td>".$mensaje."</td></tr>\n";
$cuerpo .= "<tr><th>aceptacion de la politica de la privacidad</th><td>".$privacidad."</td></tr>\n";

$cuerpo .= "</table>\n";
$cuerpo .= "</body></html>\n";

$cuerpo2 = "Nombre: ".$nombre."\n";
$cuerpo2 .= "Asunto: ".$asunto."\n";
$cuerpo2 .= "Email: ".$email."\n";
$cuerpo2 .= "Mensaje: ".$mensaje."\n";
$cuerpo2 .="Aceptación de la política de privacidad: ".$privacidad."\n";


// recaptcha
/*
$sk = '';
if(isset($_POST['g-recaptcha-response'])) {
	$captcha=$_POST['g-recaptcha-response'];
	  
	$response=json_decode(file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=".$sk."&response=".$captcha."&remoteip=".$_SERVER['REMOTE_ADDR']), true);
	if($response['success'] == true) {
*/
		require('_class.phpmailer.php');
		require('_class.smtp.php');


		$mail = new phpmailer();
		$mail->IsSMTP();
		$mail->Host			= "smtp.office365.com";
		$mail->SMTPAuth		= true; 
		$mail->SMTPSecure 	= 'tls';
		$mail->Port 		= 587;
		$mail->Username		= "ricardoalbertomujica@mataroin365.onmicrosoft.com";
		$mail->Password		= "Clasestarda1*";   

		$mail->SMTPDebug  	= 0;
		$mail->From 	  	= "ricardoalbertomujica@mataroin365.onmicrosoft.com";
		$mail->FromName   	= "Prototipo";
		$mail->CharSet		= "UTF-8";
		$mail->isHTML(true); 

		$mail->AddAddress('ricardox87@gmail.com');
		$mail->addReplyTo($email, $nombre);
		$mail->Subject 		= $asunto;

		$mail->Body = $cuerpo;
		$mail->AltBody = $cuerpo2;
		if ( $mail->Send() ) { 
			header('Location: ../formulario-correcto.html');
		} else {
			header('Location: ../formulario-error.html');
		}
/*	
	} else { // recaptcha
		header('Location: ../envio-error.html');
	}
} else { // recaptcha
	header('Location: ../envio-error.html');
}
*/
?>